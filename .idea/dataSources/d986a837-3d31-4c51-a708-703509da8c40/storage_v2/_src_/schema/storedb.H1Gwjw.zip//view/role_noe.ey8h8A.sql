create view role_noe as
select `storedb`.`user`.`user_id`  AS `user_id`,
       `storedb`.`user`.`username` AS `username`,
       `storedb`.`user`.`password` AS `password`,
       `storedb`.`user`.`name`     AS `name`,
       `storedb`.`user`.`age`      AS `age`,
       `storedb`.`user`.`sex`      AS `sex`,
       `storedb`.`user`.`tel`      AS `tel`,
       `storedb`.`user`.`role_id`  AS `role_id`,
       `storedb`.`user`.`isValid`  AS `isValid`
from `storedb`.`user`
where (`storedb`.`user`.`role_id` = '1');

